/// A module for all editor-side code.
///
/// There's not much right now
pub mod editor_plugin;
