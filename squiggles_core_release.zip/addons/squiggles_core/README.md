# Oh Deer God

This is a horror game made with Godot 4.2.1 as a proof of concept with Squiggles Core (rust ed.)

